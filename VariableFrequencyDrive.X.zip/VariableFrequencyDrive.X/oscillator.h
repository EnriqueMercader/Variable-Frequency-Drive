#ifndef OSCILLATOR_H
#define	OSCILLATOR_H
    /* Includes */
    #include <xc.h>

    /* Function prototypes */
    void oscillator_Configuration(void);

#endif	/* OSCILLATOR_H */

