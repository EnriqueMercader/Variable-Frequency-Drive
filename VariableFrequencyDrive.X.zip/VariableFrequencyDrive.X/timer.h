#ifndef TIMER_H
#define	TIMER_H
    /* Includes */
    #include <xc.h>
    #define _XTAL_FREQ 32000000
    #define partitions 42

    /* Functions' prototypes */
    void setTimer0(int phaseFrequency);

#endif	/* TIMER_H */

