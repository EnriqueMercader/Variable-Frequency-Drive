#ifndef PWM_H
#define	PWM_H
    /* Includes */
    #include <xc.h>

    /* Function prototypes */
    void pwm_start(void);

#endif	/* PWM_H */

